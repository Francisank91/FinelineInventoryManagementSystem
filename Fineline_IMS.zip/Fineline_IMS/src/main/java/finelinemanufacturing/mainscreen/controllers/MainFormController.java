package finelinemanufacturing.mainscreen.controllers;

import models.Inventory;
import models.Part;
import models.Product;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 *Main screen of the company application.
 */
public class MainFormController implements Initializable {
    //Set Stage & Scene
    Stage stage;
    Parent scene;

    @FXML
    private TableView<Part> partsTableView;
    @FXML
    private TableColumn<Part,Integer> partsIdCol;
    @FXML
    private TableColumn<Part,String> partsNameCol;
    @FXML
    private TableColumn<Part,Integer> partsInventoryLevelCol;
    @FXML
    private TableColumn<Part,Double> partsPriceCostUnitCol;
    @FXML
    private TextField searchPartIdNameTxt;
    @FXML
    private TableView<Product> productsTableView;
    @FXML
    private TableColumn<Product,Integer> productIdCol;
    @FXML
    private TableColumn<Product,String> productNameCol;
    @FXML
    private TableColumn<Product,Integer> productInventoryLevelCol;
    @FXML
    private TableColumn<Product,Integer> productPriceCostUnitCol;
    @FXML
    private TextField searchProductIdNameTxt;
    @FXML
    private Button exitImsBtn;

    /**
     *Navigates user to the add part screen.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionAddPart(ActionEvent actionEvent) throws IOException {
    //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AddPartForm.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    //Select Part Method

    /**
     *Returns a match of parts when given an integer.
     * @param id
     * @return
     */
    public Part selectPart(int id){

        for(Part part : Inventory.getAllParts()){
            if (part.getId() == id) {
                return part;


            }
        }
        return null;
    }





    /**
     *Deletes a selected part from the inventory list upon confirmation.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionDeletePart(ActionEvent actionEvent) throws IOException {

        //Confirmation Dialog Box Creation
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION,"Are you sure you want to delete this part?");// Dialog Box
        Optional<ButtonType> result = alert1.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK) {


            try {
                Part partSelection = partsTableView.getSelectionModel().getSelectedItem();//gets selected ID
                int partID = partSelection.getId();

                if (partSelection == selectPart(partID)) {
                    delete(partID);
                    System.out.println(partSelection.getName() + " " + "Deleted!");
                } else {
                    System.out.println("No Match.");

                }
            }
            catch(NullPointerException ex){
                /*System.out.println("No part selected");
                System.out.println("Exception" + ex);*/
                //Error Dialog Box Creation
                Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                alert.setTitle(("Error Dialog"));
                alert.setContentText("No Part selected");
                alert.showAndWait();

                /*/Warning Dialog Box Creation
                Alert alert = new Alert(Alert.AlertType.WARNING);// Dialog Box
                alert.setTitle(("Warning Dialog"));
                alert.setContentText("No Part selected");
                alert.showAndWait();*/

            }

            //Return to Main Menu
            stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
            scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }











    }
    //Delete Part Method

    /**
     *Uses the ID of a part to delete the identified part from the inventory list.
     * @param id
     * @return
     */
    public boolean delete(int id){

        for(Part part : Inventory.getAllParts()){
            if(part.getId() == id){
                return Inventory.getAllParts().remove(part);
            }
        }
        return false;

    }


    /**
     * Navigates user to the add Product screen
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionAddProduct(ActionEvent actionEvent) throws IOException {
        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AddProductForm.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     *Navigates user to the modify part screen, along with the information about the part.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionUpdatePart(ActionEvent actionEvent) throws IOException {

        try {
            //get selected assets
            //partsTableView.getSelectionModel().getSelectedItem().getId();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ModifyPartForm.fxml"));
            loader.load();

            ModifyPartFormController MPFController = loader.getController(); //calls controller methods from animal details

            MPFController.sendPartDetails(partsTableView.getSelectionModel().getSelectedItem());//Send data from selected

            //Cast&Link button to scene
            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();
        }  catch(NullPointerException ex){

            //Error Dialog Box Creation
            Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
            alert.setTitle(("Error Dialog"));
            alert.setContentText("No Part selected");
            alert.showAndWait();


        }
    }

    /**
     *Navigates user to the modify product screen, along with the information about the product.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    public void onActionUpdateProduct(ActionEvent actionEvent) throws IOException {

        try {
            //get selected assets
            //partsTableView.getSelectionModel().getSelectedItem().getId();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ModifyProductForm.fxml"));
            loader.load();

            ModifyProductFormController MPFController = loader.getController(); //calls controller methods

            MPFController.sendProductDetails(productsTableView.getSelectionModel().getSelectedItem());//Send data from selected


            //Cast&Link button to scene
            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();

        } catch(NullPointerException ex){

            //Error Dialog Box Creation
            Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
            alert.setTitle(("Error Dialog"));
            alert.setContentText("No Product selected");
            alert.showAndWait();


        }

    }



    //Select Part Method

    /**
     *Returns a match of products when given an integer.
     * @param id
     * @return
     */
    public Product selectProduct(int id){

        for(Product product : Inventory.getAllProducts()){
            if (product.getId() == id) {
                return product;


            }
        }
        return null;
    }

    /**
     *Deletes a selected product from the inventory list upon confirmation.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionDeleteProduct(ActionEvent actionEvent) throws IOException {
        //Delete Product
        //Confirmation Dialog Box Creation
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION,"Are you sure you want to delete this product?");// Dialog Box
        Optional<ButtonType> result = alert1.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK) {

            Product productSelection = productsTableView.getSelectionModel().getSelectedItem();//gets selected ID
            if (productSelection.getAllAssociatedParts().isEmpty()) {
                try {
                   // Product productSelection = productsTableView.getSelectionModel().getSelectedItem();//gets selected ID
                    int productID = productSelection.getId();

                    if (productSelection == selectProduct(productID)) {
                        deleteProduct(productID);
                        //productSelection.getAllAssociatedParts().clear();
                        System.out.println(productSelection.getName() + " " + "Deleted!");
                       // System.out.println(productSelection.getName() + "Associated Part List Size = " + productSelection.getAllAssociatedParts().size());
                    } else {
                        System.out.println("No Match.");

                    }
                } catch (NullPointerException ex) {

                    //Error Dialog Box Creation
                    Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                    alert.setTitle(("Error Dialog"));
                    alert.setContentText("No Product selected");
                    alert.showAndWait();


                }

                //Return to Main Menu
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
                scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
                stage.setScene(new Scene(scene));
                stage.show();
            }else{
                //Error Dialog Box Creation
                Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                alert.setTitle(("Product Deletion Error"));
                alert.setContentText("Associated parts need to be removed before deletion.");
                alert.showAndWait();
            }


        }




    }



    /**
     *Uses the ID of a product to delete the identified product from the inventory list.
     * @param id
     * @return
     */
    public boolean deleteProduct(int id){

        for(Product product : Inventory.getAllProducts()){
            if(product.getId() == id){
                return Inventory.getAllProducts().remove(product);
            }
        }
        return false;

    }


    /**
     *Exits the company application.
     * @param actionEvent
     */
    @FXML
    void onActionExitIms(ActionEvent actionEvent) {
        //Exit Button
        System.exit(0);
    }

    /**
     *Uses input from the search bar to lookup part matches.
     * @param event
     */
    public void onActionLookupPart(ActionEvent event) {
      //Lookup Part
       String partName = searchPartIdNameTxt.getText();//get search
       ObservableList<Part> parts = Inventory.lookupPart(partName);

        //ID return
        if(parts.size() == 0){//name has no numbers
            try {

                          if(partName.indexOf('a') == -1 &&
                                            partName.indexOf('b') == -1 &&
                                            partName.indexOf('c') == -1 &&
                                            partName.indexOf('d') == -1 &&
                                            partName.indexOf('e') == -1 &&
                                            partName.indexOf('f') == -1 &&
                                            partName.indexOf('g') == -1 &&
                                            partName.indexOf('h') == -1 &&
                                            partName.indexOf('i') == -1 &&
                                            partName.indexOf('j') == -1 &&
                                            partName.indexOf('k') == -1 &&
                                            partName.indexOf('l') == -1 &&
                                            partName.indexOf('m') == -1 &&
                                            partName.indexOf('n') == -1 &&
                                            partName.indexOf('o') == -1 &&
                                            partName.indexOf('p') == -1 &&
                                            partName.indexOf('q') == -1 &&
                                            partName.indexOf('r') == -1 &&
                                            partName.indexOf('s') == -1 &&
                                            partName.indexOf('t') == -1 &&
                                            partName.indexOf('u') == -1 &&
                                            partName.indexOf('v') == -1 &&
                                            partName.indexOf('w') == -1 &&
                                            partName.indexOf('x') == -1 &&
                                            partName.indexOf('y') == -1 &&
                                            partName.indexOf('z') == -1
                            )
                          {
                            int partID = Integer.parseInt(partName);//Is there an integer in the query?
                            Part p = Inventory.lookupPart(partID);
                            if (p != null) {
                                parts.add(p);

                            }
                            else{
                                searchPartIdNameTxt.setText("No parts found, try again");
                                partsTableView.setItems(parts);
                                Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                                alert.setTitle(("Error Dialog"));
                                alert.setContentText("Part Not Found, Try Again.");
                                alert.showAndWait();
                                searchPartIdNameTxt.setText("");

                            }
                          }else {
                              System.out.println("Test works Else");
                              searchPartIdNameTxt.setText("Input invalid, enter exact partID OR name");
                              partsTableView.setItems(parts);
                              Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                              alert.setTitle(("Error Dialog"));
                              alert.setContentText("Input invalid, enter exact partID OR name and try again.");
                              alert.showAndWait();
                              searchPartIdNameTxt.setText("");
                          }






            }
            catch (NumberFormatException e){
                //ignore

            }


        }

        if (parts.size() > 0){
            partsTableView.setItems(parts);
        }else {
            partsTableView.setItems(Inventory.getAllParts());
        }

        System.out.println(Integer.toString(parts.size()) + " parts returned.");
        searchPartIdNameTxt.setText("");//Clears query after search
    }

    /**
     *Uses input from the search bar to lookup product matches.
     * @param event
     */
    public void onActionLookupProduct(ActionEvent event) {
        String productName = searchProductIdNameTxt.getText();//get search
        ObservableList<Product> products = Inventory.lookupProduct(productName);




        //ID return original
        if(products.size() == 0){//name has no numbers
            try {
                if (productName.indexOf('a') == -1 &&
                        productName.indexOf('b') == -1 &&
                        productName.indexOf('c') == -1 &&
                        productName.indexOf('d') == -1 &&
                        productName.indexOf('e') == -1 &&
                        productName.indexOf('f') == -1 &&
                        productName.indexOf('g') == -1 &&
                        productName.indexOf('h') == -1 &&
                        productName.indexOf('i') == -1 &&
                        productName.indexOf('j') == -1 &&
                        productName.indexOf('k') == -1 &&
                        productName.indexOf('l') == -1 &&
                        productName.indexOf('m') == -1 &&
                        productName.indexOf('n') == -1 &&
                        productName.indexOf('o') == -1 &&
                        productName.indexOf('p') == -1 &&
                        productName.indexOf('q') == -1 &&
                        productName.indexOf('r') == -1 &&
                        productName.indexOf('s') == -1 &&
                        productName.indexOf('t') == -1 &&
                        productName.indexOf('u') == -1 &&
                        productName.indexOf('v') == -1 &&
                        productName.indexOf('w') == -1 &&
                        productName.indexOf('x') == -1 &&
                        productName.indexOf('y') == -1 &&
                        productName.indexOf('z') == -1
                ) {
                    int productID = Integer.parseInt(productName);//Is there an integer in the query?
                    Product p = Inventory.lookupProduct(productID);
                    if (p != null) {
                        products.add(p);


                    } else {
                        searchProductIdNameTxt.setText("No products found, try again");
                        productsTableView.setItems(products);
                        Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                        alert.setTitle(("Error Dialog"));
                        alert.setContentText("Product Not Found, Try Again.");
                        alert.showAndWait();
                        searchProductIdNameTxt.setText("");

                    }

                }
                else {
                    System.out.println("Test works Else");
                    searchPartIdNameTxt.setText("Input invalid, enter exact partID OR name");
                    productsTableView.setItems(products);
                    Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                    alert.setTitle(("Error Dialog"));
                    alert.setContentText("Input invalid, enter exact productID OR name and try again.");
                    alert.showAndWait();
                    searchPartIdNameTxt.setText("");
                }
            }
            catch (NumberFormatException e) {
                        //ignore

            }


        }
        if (products.size() > 0) {
            productsTableView.setItems(products);
        }else {
            productsTableView.setItems(Inventory.getAllProducts());
        }



        System.out.println(Integer.toString(products.size()) + " products returned.");
        searchProductIdNameTxt.setText("");//Clears query after search

    }


    /**
     *Initilization of the Main form. Table view columns are defined and set.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {




        partsIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partsNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partsInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partsPriceCostUnitCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        productsTableView.setItems(Inventory.getAllProducts());

        productIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceCostUnitCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        ObservableList<Part> allParts = Inventory.getAllParts();
        partsTableView.setItems(allParts);










    }


}