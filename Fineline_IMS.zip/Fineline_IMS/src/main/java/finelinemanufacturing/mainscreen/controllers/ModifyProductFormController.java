package finelinemanufacturing.mainscreen.controllers;

import models.Inventory;
import models.Part;
import models.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.*;//imports all scene controls
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Form to make updates to created products.
 */
public class ModifyProductFormController implements Initializable {
    //Set Stage & Scene
    Stage stage;
    Parent scene;

    @FXML
    private TextField productIdTxt;
    @FXML
    private TextField productNameTxt;
    @FXML
    private TextField productInventoryTxt;
    @FXML
    private TextField productPriceTxt;
    @FXML
    private TextField maxProductNumTxt;
    @FXML
    private TextField minProductNumTxt;
    @FXML
    private TextField searchPartIdNameTxt;
    @FXML
    private TableColumn<Part,Integer> addPartIdCol;
    @FXML
    private TableColumn<Part,String> addPartNameCol;
    @FXML
    private TableColumn<Part,Integer> addInventoryLevelCol;
    @FXML
    private TableColumn<Part,Double> addPriceCostUnitCol;
    @FXML
    private Button productAddBtn;
    @FXML
    private TableColumn<Part,Integer> removePartIdCol;
    @FXML
    private TableColumn<Part,String> removePartNameCol;
    @FXML
    private TableColumn<Part,Integer> removeInventoryLevelCol;
    @FXML
    private TableColumn<Part,Integer> removePriceCostUnitCol;
    @FXML
    private Button RemoveAssociatedPartBtn;
    @FXML
    private Button saveProductBtn;
    @FXML
    private Button productCancelBtn;
    @FXML
    private TableView<Part> addPartTableView;
    @FXML
    private TableView<Part> associatedPartTableView;





    ObservableList<Part> APL = FXCollections.observableArrayList();


    /**
     *Confirms the addition of an associated part to the products existing associated part list.
     * @param actionEvent
     */
    @FXML
    public void onActionAddPart(ActionEvent actionEvent) {

        if(addPartTableView.getSelectionModel().getSelectedItem() != null) {
            Part AAPart = addPartTableView.getSelectionModel().getSelectedItem();
            Product AAProduct = Inventory.getAllProducts().get(Integer.parseInt((productIdTxt.getText())) - 1);
            AAProduct.addAssociatedPart(AAPart);

            APL.setAll(AAProduct.getAllAssociatedParts());
            System.out.println(APL.size());
        }

    }

    /**
     *Confirms the removal of an associated part to the products existing associated part list.
     * @param actionEvent
     */
    @FXML
    void onActionRemoveAssociatedPart(ActionEvent actionEvent) {


        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION,"Are you sure you want to delete this associated part?");// Dialog Box
        Optional<ButtonType> result = alert1.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK) {


            Part AAPart = associatedPartTableView.getSelectionModel().getSelectedItem();
            Product AAProduct = Inventory.getAllProducts().get(Integer.parseInt((productIdTxt.getText())) - 1);
            AAProduct.getAllAssociatedParts().remove(AAPart);

            APL.setAll(AAProduct.getAllAssociatedParts());
            System.out.println(APL.size());

        }
    }

    /**
     *Confirms the modifications for the product and associated part list to the product.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionSavePart(ActionEvent actionEvent) throws IOException {
        try {

            //retrieve values InHouse
            int id = Integer.parseInt(productIdTxt.getText());
            String name = productNameTxt.getText();
            int stock = Integer.parseInt(productInventoryTxt.getText());
            int maxNum = Integer.parseInt(maxProductNumTxt.getText());
            int minNum = Integer.parseInt(minProductNumTxt.getText());
            double price = Double.parseDouble(productPriceTxt.getText());
            boolean procurement; //Radio Button

            if(stock >= minNum && stock <=maxNum) {
                Product AAProduct = new Product(id, name, price, stock, minNum, maxNum);
                Inventory.getAllProducts().set((id - 1), AAProduct);


                for (Part x : APL) {
                    AAProduct.addAssociatedPart(x);
                }
                APL.setAll();


                //Cast&Link to Main
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
                scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
                stage.setScene(new Scene(scene));
                stage.show();
            }
            else {
                //Error Dialog Box Creation
                Alert alert2 = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                alert2.setTitle(("Error Dialog"));
                alert2.setContentText("Inventory must be between the Minimum and Maximum inventory");
                alert2.showAndWait();
            }
        }
        catch(NumberFormatException e){
            //Error Dialog Box Creation
            Alert alert2 = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
            alert2.setTitle(("Error Dialog"));
            alert2.setContentText( e.getMessage() + ", an improper input format has been used, please retry.");
            alert2.setResizable(true);
            alert2.setWidth(500);
            alert2.setHeight(500);
            alert2.showAndWait();
        }
    }

    /**
     *Exits the modify product form and returns to the main screen.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     *Uses input from the search bar to lookup part matches.
     * @param event
     */
    public void onActionLookupPart(ActionEvent event) {

        //Lookup Part
        String partName = searchPartIdNameTxt.getText();//get search
        ObservableList<Part> parts = Inventory.lookupPart(partName);

        //ID return
        if(parts.size() == 0){//name has no numbers
            try {
                if(partName.indexOf('a') == -1 &&
                        partName.indexOf('b') == -1 &&
                        partName.indexOf('c') == -1 &&
                        partName.indexOf('d') == -1 &&
                        partName.indexOf('e') == -1 &&
                        partName.indexOf('f') == -1 &&
                        partName.indexOf('g') == -1 &&
                        partName.indexOf('h') == -1 &&
                        partName.indexOf('i') == -1 &&
                        partName.indexOf('j') == -1 &&
                        partName.indexOf('k') == -1 &&
                        partName.indexOf('l') == -1 &&
                        partName.indexOf('m') == -1 &&
                        partName.indexOf('n') == -1 &&
                        partName.indexOf('o') == -1 &&
                        partName.indexOf('p') == -1 &&
                        partName.indexOf('q') == -1 &&
                        partName.indexOf('r') == -1 &&
                        partName.indexOf('s') == -1 &&
                        partName.indexOf('t') == -1 &&
                        partName.indexOf('u') == -1 &&
                        partName.indexOf('v') == -1 &&
                        partName.indexOf('w') == -1 &&
                        partName.indexOf('x') == -1 &&
                        partName.indexOf('y') == -1 &&
                        partName.indexOf('z') == -1
                )
                {
                int partID = Integer.parseInt(partName);//Is there an integer in the query?
                Part p = Inventory.lookupPart(partID);
                if (p!= null)
                    parts.add(p);
                else{
                    searchPartIdNameTxt.setText("No parts found, try again");
                    addPartTableView.setItems(parts);
                    Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                    alert.setTitle(("Error Dialog"));
                    alert.setContentText("Part Not Found, Try Again.");
                    alert.showAndWait();
                    searchPartIdNameTxt.setText("");

                }
                }else {
                    System.out.println("Test works Else");
                    searchPartIdNameTxt.setText("Input invalid, enter exact partID OR name");
                    addPartTableView.setItems(parts);
                    Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                    alert.setTitle(("Error Dialog"));
                    alert.setContentText("Input invalid, enter exact partID OR name and try again.");
                    alert.showAndWait();
                    searchPartIdNameTxt.setText("");
                }






            }
            catch (NumberFormatException e){
                //ignore

            }


        }
        if (parts.size() > 0) {
            addPartTableView.setItems(parts);
        }else {
            addPartTableView.setItems(Inventory.getAllParts());
        }
        System.out.println(Integer.toString(parts.size()) + " parts returned.");
        searchPartIdNameTxt.setText("");//Clears query after search



    }

    /**
     *Pre-populates product information into existing fields from selected product in the main form. Table view columns are defined and set.
     * @param product
     */
    public void sendProductDetails(Product product){
        //Pre-populate
        productIdTxt.setText(String.valueOf(product.getId()));
        productNameTxt.setText(product.getName());
        productInventoryTxt.setText(String.valueOf(product.getStock()));
        productPriceTxt.setText(String.valueOf(product.getPrice()));
        maxProductNumTxt.setText(String.valueOf(product.getMax()));
        minProductNumTxt.setText(String.valueOf(product.getMin()));



        removePartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        removePartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        removeInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        removePriceCostUnitCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        associatedPartTableView.setItems(product.getAllAssociatedParts());





    }


    /**
     *Initilization of the modify part form. Part ID input is disabled.Table view columns are defined and set.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Populate Parts table
        addPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        addPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        addInventoryLevelCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addPriceCostUnitCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        ObservableList<Part> allParts = Inventory.getAllParts();
        addPartTableView.setItems(allParts);


        //Disabled ID field
        productIdTxt.setDisable(true);



    }








}