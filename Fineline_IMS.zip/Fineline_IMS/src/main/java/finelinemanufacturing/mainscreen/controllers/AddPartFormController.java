package finelinemanufacturing.mainscreen.controllers;

import models.InHouse;
import models.Inventory;
import models.Outsourced;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static finelinemanufacturing.mainscreen.Main.newPartUid;

/**
 *Form to add new parts to inventory list.
 */
public class AddPartFormController implements Initializable {


    //Set Stage & Scene
    Stage stage;
    Parent scene;
    @FXML
    private Label procurementLbl;
    @FXML
    private RadioButton InHouseBtn;
    @FXML
    private RadioButton outSourcedBtn;
    @FXML
    private TextField partIhIdTxt;
    @FXML
    private TextField partIhNameTxt;
    @FXML
    private TextField partIhInventoryTxt;
    @FXML
    private TextField partIhPriceTxt;
    @FXML
    private TextField maxPartIhNumTxt;
    @FXML
    private TextField machineIhMachineIdTxt;
    @FXML
    private TextField minPartIhNumTxt;
    @FXML
    private TextField partOsIdTxt;
    @FXML
    private TextField partOsNameTxt;
    @FXML
    private TextField partOsInventoryTxt;
    @FXML
    private TextField partOsPriceTxt;
    @FXML
    private TextField maxPartOsNumTxt;
    @FXML
    private TextField companyNameTxt;
    @FXML
    private TextField minPartOsNumTxt;
    @FXML
    private Button savePartBtn;
    @FXML
    private Button cancelPartBtn;

    /**
     *Specifies the addition of an InHouse part.
     * @param event
     */
    @FXML
    public void onActionSwitchInHouse(ActionEvent event) {
        procurementLbl.setText("Machine ID");
        //machineIhMachineIdTxt.setPromptText("Machine ID");
        machineIhMachineIdTxt.setVisible(true);
        machineIhMachineIdTxt.setDisable(false);
        companyNameTxt.setVisible(false);
        companyNameTxt.setDisable(true);
    }

    /**
     *Specifies the addition of an outsourced part.
     * @param event
     */
    @FXML
    public void onActionSwitchOutsourced(ActionEvent event) {

        procurementLbl.setText("Company Name");
       // machineIhMachineIdTxt.setPromptText("Company Name");
        companyNameTxt.setVisible(true);
        companyNameTxt.setDisable(false);
        machineIhMachineIdTxt.setVisible(false);
        machineIhMachineIdTxt.setDisable(true);

    }


    /**
     *Specifies parameters and adds InHouse and outsourced parts to their respective lists.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    public void onActionSavePart(ActionEvent actionEvent) throws IOException {
        try {
            //retrieve values InHouse
            int id = 1;//Integer.parseInt(partIhIdTxt.getText());
            String name = partIhNameTxt.getText();
            int stock = Integer.parseInt(partIhInventoryTxt.getText());
            int maxNum = Integer.parseInt(maxPartIhNumTxt.getText());
            int minNum = Integer.parseInt(minPartIhNumTxt.getText());
            double price = Double.parseDouble(partIhPriceTxt.getText());
            boolean procurement; //Radio Button


            if (maxNum < minNum) {

                //Error Dialog Box Creation
                Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                alert.setTitle(("Error Dialog"));
                alert.setContentText("Minimum inventory must be less than Maximum inventory");
                alert.showAndWait();


            }
            if(stock >= minNum && stock <=maxNum) {


                //Procurement Selected?
                if (InHouseBtn.isSelected()) {
                    int machineId = Integer.parseInt(machineIhMachineIdTxt.getText());
                    Inventory.addPart(new InHouse(newPartUid(), name, price, stock, minNum, maxNum, machineId));
                } else {
                    String companyName = companyNameTxt.getText();
                    Inventory.addPart(new Outsourced(newPartUid(), name, price, stock, minNum, maxNum, companyName));
                }
                //Create New object item
                // Add is selected
                //Inventory.addPart(new InHouse(id,name,price,stock,minNum,maxNum,machineId));


                //Cast&Link to Main
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
                scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
                stage.setScene(new Scene(scene));
                stage.show();

            }
            else {
                //Error Dialog Box Creation
                Alert alert2 = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                alert2.setTitle(("Error Dialog"));
                alert2.setContentText("Inventory must be between the Minimum and Maximum inventory");
                alert2.showAndWait();
            }
        }
        catch(NumberFormatException e){
            //Error Dialog Box Creation
            Alert alert2 = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
            alert2.setTitle(("Error Dialog"));
            alert2.setContentText( e.getMessage() + ", an improper input format has been used, please retry.");
            alert2.setResizable(true);
            alert2.setWidth(500);
            alert2.setHeight(500);
            alert2.showAndWait();

        }
    }

    /**
     *Exits the add part form and returns to the main screen.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void OnActionCancelModifyPart(ActionEvent actionEvent) throws IOException {
        //Cast&Link to Main
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Initilization of the add part form. Part ID input is disabled and is auto-generated.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Disabled ID field
        partIhIdTxt.setDisable(true);
        partIhIdTxt.setPromptText("Auto Gen-Disabled");
    }
}