package finelinemanufacturing.mainscreen.controllers;

import models.InHouse;
import models.Inventory;
import models.Outsourced;
import models.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 *Form to make updates to created parts.
 */
public class ModifyPartFormController implements Initializable {
    public Label procurementLbl;
    //Set Stage & Scene
    Stage stage;
    Parent scene;

    @FXML
    private RadioButton InHouseBtn;


    @FXML
    private RadioButton outSourcedBtn;
    @FXML
    private TextField productIhIdTxt;
    @FXML
    private TextField productIhNameTxt;
    @FXML
    private TextField productIhInventoryTxt;
    @FXML
    private TextField productIhPriceTxt;
    @FXML
    private TextField maxProductIhNumTxt;
    @FXML
    private TextField machineIhMachineIdTxt;
    @FXML
    private TextField minProductIhNumTxt;
    @FXML
    private TextField productIdTxt;
    @FXML
    private TextField productNameTxt;
    @FXML
    private TextField productInventoryTxt;
    @FXML
    private TextField productPriceTxt;
    @FXML
    private TextField maxProductNumTxt;
    @FXML
    private TextField companyNameTxt;
    @FXML
    private TextField minProductNumTxt;
    @FXML
    private Button savePartBtn;
    @FXML
    private Button cancelPartBtn;


    /**
     *Specifies the modification of an InHouse part.
     * @param actionEvent
     */
    @FXML
    void onActionSwitchInHouse(ActionEvent actionEvent) {
        procurementLbl.setText("Machine ID");

        machineIhMachineIdTxt.setVisible(true);
        machineIhMachineIdTxt.setDisable(false);
        companyNameTxt.setVisible(false);
        companyNameTxt.setDisable(true);
    }

    /**
     *Specifies the modification of an outsourced part.
     * @param actionEvent
     */
    @FXML
    void onActionSwitchOutsourced(ActionEvent actionEvent) {

        procurementLbl.setText("Company Name");

        companyNameTxt.setVisible(true);
        companyNameTxt.setDisable(false);
        machineIhMachineIdTxt.setVisible(false);
        machineIhMachineIdTxt.setDisable(true);


    }

    /**
     *Specifies parameters and modifies InHouse and outsourced parts within their respective lists.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void onActionSavePart(ActionEvent actionEvent) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/MainForm.fxml"));
            loader.load();

            //retrieve values InHouse
            int id = Integer.parseInt(productIhIdTxt.getText());
            String name = productIhNameTxt.getText();
            int stock = Integer.parseInt(productIhInventoryTxt.getText());
            int maxNum = Integer.parseInt(maxProductIhNumTxt.getText());
            int minNum = Integer.parseInt(minProductIhNumTxt.getText());
            double price = Double.parseDouble(productIhPriceTxt.getText());
            boolean procurement; //Radio Button

            if (stock >= minNum && stock <= maxNum) {


                //Procurement Selected?
                if (InHouseBtn.isSelected()) {
                    //Modify Parts
                    int machineId = Integer.parseInt(machineIhMachineIdTxt.getText());
                    //Send data from selected
                    InHouse modifiedIHPart = new InHouse(id, name, price, stock, minNum, maxNum, machineId);
                    Inventory.getAllParts().set((id - 1), modifiedIHPart);
                } else {
                    //Modify Parts
                    String companyName = companyNameTxt.getText();
                    Outsourced modifiedOSPart = new Outsourced(id, name, price, stock, minNum, maxNum, companyName);
                    Inventory.getAllParts().set((id - 1), modifiedOSPart);


                }
                //Cast&Link button to scene
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
                scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
                stage.setScene(new Scene(scene));
                stage.show();
            }
            else {
                //Error Dialog Box Creation
                Alert alert2 = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
                alert2.setTitle(("Error Dialog"));
                alert2.setContentText("Inventory must be between the Minimum and Maximum inventory");
                alert2.showAndWait();
            }
        }
         catch(NumberFormatException e) {
             //Error Dialog Box Creation
             Alert alert2 = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
             alert2.setTitle(("Error Dialog"));
             alert2.setContentText( e.getMessage() + ", an improper input format has been used, please retry.");
             alert2.setResizable(true);
             alert2.setWidth(500);
             alert2.setHeight(500);
             alert2.showAndWait();
         }


    }

    /**
     *Exits the modify part form and returns to the main screen.
     * @param actionEvent
     * @throws IOException
     */
    @FXML
    void OnActionCancelModifyPart(ActionEvent actionEvent) throws IOException {
        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/MainForm.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     *Pre-populates part information into existing fields from selected part in the main form.
     * @param part
     */
    public void sendPartDetails(Part part){
        //Pre-populate
        productIhIdTxt.setText(String.valueOf(part.getId()));
        productIhNameTxt.setText(part.getName());
        productIhInventoryTxt.setText(String.valueOf(part.getStock()));
        productIhPriceTxt.setText(String.valueOf(part.getPrice()));
        maxProductIhNumTxt.setText(String.valueOf(part.getMax()));
        minProductIhNumTxt.setText(String.valueOf(part.getMin()));

        if(part instanceof InHouse) {
            machineIhMachineIdTxt.setText(String.valueOf(((InHouse) part).getMachineID()));
            InHouseBtn.selectedProperty().set(true);


            procurementLbl.setText("Machine ID");
            //machineIhMachineIdTxt.setPromptText("Machine ID");
            machineIhMachineIdTxt.setVisible(true);
            machineIhMachineIdTxt.setDisable(false);
            companyNameTxt.setVisible(false);
            companyNameTxt.setDisable(true);
        }
        if(part instanceof Outsourced) {
            companyNameTxt.setText(String.valueOf(((Outsourced) part).getCompanyName()));
            outSourcedBtn.selectedProperty().set(true);

            procurementLbl.setText("Company Name");
            // machineIhMachineIdTxt.setPromptText("Company Name");
            companyNameTxt.setVisible(true);
            companyNameTxt.setDisable(false);
            machineIhMachineIdTxt.setVisible(false);
            machineIhMachineIdTxt.setDisable(true);
        }




    }


    /**
     *Initilization of the modify part form. Part ID input is disabled.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        //Disabled ID field
        productIhIdTxt.setDisable(true);


    }
}