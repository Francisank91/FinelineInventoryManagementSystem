package finelinemanufacturing.mainscreen;

import models.InHouse;
import models.Inventory;
import models.Outsourced;
import models.Product;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * This is the main class for the Inventory software that adds,removes, modifies, and displays inventory for the company.
 *
 *FUTURE ENHANCEMENT - Enhance Add / Modify Product functionalities to display the multiples of an associated part, for each product, on one line. Create low stock warnings for part additions.
 *
 *
 */
public class Main extends Application {


    /**
     * The start method is called once the launched method has been processed. The MainForm FXML screen is launched as the face of the program.
     * @param stage
     * @throws IOException
     */
    @Override
    public void start(Stage stage) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    // Part ID generator
    static int partUID = 1;

    /**
     * Returns incremented ID for new parts.
     * @return
     */
    public static int newPartUid(){
        return partUID++;
    }

    // Product ID generator
    static int productUID = 1;

    /**
     * Returns incremented ID for new products.
     * @return
     */
    public static int newProductUid(){
        return productUID++;
    }


    /**
     * Main is the first block of java code that is called when the application starts. Initial parts and products are defined and added to their respective lists.
     * @param args
     */
    public static void main(String[] args) {


        //Import Product Objects Here
        Product product1 = new Product(newProductUid(),"Fineline Adventure Bike",139.0,50,10,100);
        Product product2 = new Product(newProductUid(),"Fineline Lux Bike",999.0,10,10,100);
        Product product3 = new Product(newProductUid(),"Fineline BMX Bike",499.0,30,10,100);



        //Import Part Objects Here
        InHouse part1 = new InHouse(newPartUid(),"Brakes",12.99,15,1,20,1);
        Outsourced part2 = new Outsourced(newPartUid(),"Spokes",13.99,16,1,60,"Riley Bike Parts");
        InHouse part3 = new InHouse(newPartUid(),"Frame",49.99,17,1,20,1);
        Outsourced part4 = new Outsourced(newPartUid(),"Wheel",29.99,25,2,18,"Diamond Bike Parts");
        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addPart(part3);
        Inventory.addPart(part4);

        Inventory.addProduct(product1);
        Inventory.addProduct(product2);
        Inventory.addProduct(product3);


        launch(args);
    }


}