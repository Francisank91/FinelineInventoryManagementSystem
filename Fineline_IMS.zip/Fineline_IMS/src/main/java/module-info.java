module finelinemanufacturing.mainscreen {
    requires javafx.controls;
    requires javafx.fxml;


    opens finelinemanufacturing.mainscreen to javafx.fxml;
    exports finelinemanufacturing.mainscreen;
    opens finelinemanufacturing.mainscreen.controllers to javafx.fxml;
    exports finelinemanufacturing.mainscreen.controllers;
    opens models to javafx.base;
    exports models;

}