package models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * The Inventory class models the inventory for company parts and products
 */
public class Inventory{


    private static ObservableList<Part> getAllParts = FXCollections.observableArrayList();

    private static ObservableList<Product> getAllProducts = FXCollections.observableArrayList();

    //Methods

    /**
     * Add new part to list
     * @param newPart
     */
    public static void addPart(Part newPart) {

        getAllParts.add(newPart);
    }

    /**
     * Returns parts list
     * @return
     */
    public static ObservableList<Part> getAllParts() {

        return getAllParts;
    }

    /**
     * Add new product to list
     * @param newProduct
     */
    public static void addProduct(Product newProduct) {

        getAllProducts.add(newProduct);
    }

    /**
     * Returns products list
     * @return
     */
    public static ObservableList<Product> getAllProducts() {

        return getAllProducts;
    }


    /**
     * Searches through the part list and returns a list of parts that matches the string query.
     * @param partName
     * @return
     */
    public static ObservableList<Part> lookupPart(String partName) {

        ObservableList<Part> namedParts = FXCollections.observableArrayList();
        ObservableList<Part> allParts = Inventory.getAllParts();

        for(Part bp : allParts){
            if(bp.getName().contains(partName)){
                namedParts.add(bp);
            }
        }

        return namedParts;
    }

    /**
     * Returns matched list of parts that matches the integer query
     * @param partID
     * @return
     */
    public static Part lookupPart(int partID){

        ObservableList<Part> allParts = Inventory.getAllParts();

        for(int i = 0; i < allParts.size(); i++){
            Part p = allParts.get(i);

            if(p.getId() == partID){{
                return p;
            }}
        }



        return null;
    }

    /**
     * Searches through the part list and returns a list of products that matches the string query.
     * @param productName
     * @return
     */
    public static ObservableList<Product> lookupProduct(String productName) {

        ObservableList<Product> namedProducts = FXCollections.observableArrayList();
        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for(Product bp : allProducts){
            if(bp.getName().contains(productName)){
                namedProducts.add(bp);
            }
        }



        return namedProducts;
    }


    /**
     * Returns matched list of products that matches the integer query
     * @param productID
     * @return
     */
    public static Product lookupProduct (int productID){
        //Pass in exact ID to return a single product, return null if not found

        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for(int i = 0; i < allProducts.size(); i++){
            Product p = allProducts.get(i);

            if(p.getId() == productID){{
                return p;
            }}
        }


        return null;
    }

    /**
     * FOR FUTURE DEVELOPMENTS: Updates part in list
     * @param index
     * @param selectedPart
     */
    public static void updatePart(int index, Part selectedPart){

    }

    /**
     * FOR FUTURE DEVELOPMENTS: Updates Product in list
     * @param index
     * @param newProduct
     */
    public static void updateProduct(int index, Product newProduct){

    }

    /**
     * FOR FUTURE DEVELOPMENTS: Deletes part in list
     * @param selectedPart
     * @return
     */
    public static boolean deletePart(Part selectedPart){

        return false;
    }

    /**
     * FOR FUTURE DEVELOPMENTS: Deletes product in list
     * @param selectedProduct
     */
    public static void deleteProduct(Product selectedProduct){

    }

}
