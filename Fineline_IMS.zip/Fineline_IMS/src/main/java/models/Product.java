package models;

import models.Part;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * The Product class models the inventory for products and its associated parts
 */
public class Product implements Initializable {
    /**
     * Create private inventory fields for id,name,price,stock,min,and max
     */
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    //Array list
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    //Declare Constructor
    public Product(int id,String name,double price,int stock,int min,int max){
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;

    }


    /**
     * Return product ID
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     * Set product ID
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Return product name
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Set product name
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Return product price
     * @return
     */
    public double getPrice() {
        return price;
    }

    /**
     * set product price
     * @param price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Return product inventory
     * @return
     */
    public int getStock() {
        return stock;
    }

    /**
     * Set product inventory
     * @param stock
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Return product minimum inventory
     * @return
     */
    public int getMin() {
        return min;
    }

    /**
     * Set product minimum inventory
     * @param min
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**
     * Return product max inventory
     * @return
     */
    public int getMax() {
        return max;
    }

    /**
     * Set product max inventory
     * @param max
     */
    public void setMax(int max) {
        this.max = max;
    }

    /**
     * Returns all associated parts
     * @return
     */
    public ObservableList<Part> getAllAssociatedParts() {

        return associatedParts;
    }

    /**
     * Adds associated part to list
     * @param associatedPart
     */
    public void addAssociatedPart(Part associatedPart) {

        associatedParts.add(associatedPart);
    }

    /**
     * Remove associated part from list
     * @param selectedAssociatedPart
     * @return
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        associatedParts.remove(selectedAssociatedPart);
        return true;
    }


    /**
     * Null initializer
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {




    }
}
