package models;

import models.Part;
/**
 * The Outsourced class model is a child of the parts model for external parts
 */
public class Outsourced extends Part {

    /**
     * Company Name of outsourced part
     */
    private String CompanyName;

    //Declare Constructor

    public Outsourced(int id,String name,double price,int stock,int min,int max,String companyName) {
        super(id, name, price, stock, min, max);
        CompanyName = companyName;
    }

    /**
     * Return outsourced company name
     * @return
     */
    public String getCompanyName() {
        return CompanyName;
    }

    /**
     * Set outsourced company name
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }



}
