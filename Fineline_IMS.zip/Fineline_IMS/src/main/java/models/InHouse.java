package models;

import models.Part;

/**
 * The InHouse class model is a child of the parts model for internal parts
 */
public class InHouse extends Part {
    /**
     * Internal machine ID of part
     */
    private int machineID;

    //Declare Constructor
    public InHouse(int id,String name,double price,int stock,int min,int max,int machineID) {
        super(id, name, price, stock, min, max);
        this.machineID = machineID;
    }



    /**
     * Return machine ID
     * @return
     */
    public int getMachineID() {
        return machineID;
    }

    /**
     * Set machine ID
     * @param machineID
     */
    public void setMachineID(int machineID) {
        this.machineID = machineID;
    }
}
